
from psychopy import visual, core, event,gui
import random as rd

# Create dlg
dlg = gui.Dlg(title="My experiment", pos=(200, 400))
# Add each field manually
dlg.addText('Subject Info', color='Blue')
dlg.addField('gender:',tip = 'male or female')
dlg.addField('Name:', tip='or subject code')
dlg.addField('Age:', 21)
'''
dlg.addText('Experiment blocks', color='Blue')
dlg.addField('', 45)
'''
# Call show() to show the dlg and wait for it to close (this was automatic with DlgFromDict
thisInfo = dlg.show()

if dlg.OK: # This will be True if user hit OK...
    print(thisInfo)
    gender, name, age = thisInfo
    fileName = f'{gender}_{name}_{age}.csv'
else:
    print('User cancelled') # ...or False, if they hit Cancel
    core.quit()

# open a window
win = visual.Window([1000,800],units = 'pix')

# draw the texture
sti = visual.GratingStim(win, tex = None, mask = 'circle',
                        size = 100)
      
# creating a clock for timing
clk = core.Clock()

# open a data file
data = open(fileName,'w')
data.write(f'gender\tname\tage\tkeyPressed\tresponseTime\tcolor\tresponse\n')
for i in range(10):
    # event in a single trial
    # show the target disk
    sti_color = rd.choice(['red','green'])
    sti.color = sti_color
    x = 900*rd.random()-450
    y = 700*rd.random()-350
    sti.pos = [x,y]
    
    
    # get the start time 
    #onset = core.getAbsTime()
    clk.reset()
    
    # get the key response
    for i in range(120):
        sti.draw()
        win.flip()
        res = event.getKeys(keyList = ['space'],timeStamped = clk)
        if len(res)>0:
            key,restime = res[0]
            break
        
  
    
    # record the response information
    if sti_color == 'red':
        if len(res)==0:
            response = 'miss'
        else:
            response = 'hit'
    else:
        if len(res)>0:
            response = 'false alarm'
        else:
            response = '(green no response)'
    
    if len(res)==0:
        key = 'nan'
        restime = 'nan'
    # save data to datafile
    _d = f'{gender}\t{name}\t{age}\t{key}\t{restime}\t{sti_color}\t{response}\n'
    data.write(_d)

    # clear the window, wait for the next trial
    win.color = [0,0,0]
    win.flip()
    core.wait(1+rd.random())


# close the window 
win.close()
data.close()