# sci-plot-example

A simple framework for generating academic publication-ready figures directly using Matplotlib.