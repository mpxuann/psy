Agegroup = [sum26/cnt26,sum31/cnt31,sum36/cnt36,sum41/cnt41, sum46/cnt46, sum51/cnt51,sum56/cnt56,sum61/cnt61];
