% 运行这个文件
% run this file
HaoLink